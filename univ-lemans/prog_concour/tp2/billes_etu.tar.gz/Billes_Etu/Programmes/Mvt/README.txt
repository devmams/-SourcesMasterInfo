/*! 
  \file README.txt 
  \brief Pr�sentation des fichiers du r�pertoire Mvt

  Ce r�pertoire contient les fichiers relatifs aux mouvements des billes sur l'aire
 
*/

#ifndef _SENS_STRING_H_
#define _SENS_STRING_H_

/* Types */

#include <sens.h>

/* Fonctions */

extern char * sens_string( sens_t s ) ;
extern char * sens_blanc_string() ;
extern char * sens_vide_string() ;

#endif
